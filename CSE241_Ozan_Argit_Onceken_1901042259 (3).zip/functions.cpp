#include"myLib.h"
int Hex::gameCount=0;
void Hex::playGame()
{
    do{
        cout<<"Enter the size:"<<endl;
        cin>>size_of_board;
    }while(size_of_board<6);
    cout<<"2 player?(Y/N)"<<endl;
    char yesno;
    cin>>yesno;
    yesno =='Y'?player2=true:player2=false;
    createBoard();
}
void Hex::createBoard(){
    gameCount++;
    hexCells=new Cell*[size_of_board+2];
    for (int i = 0; i <= size_of_board+2; i++)
        hexCells[i]=new Cell[size_of_board+2];
    for (int i = 0; i < size_of_board+2; i++)
        hexCells[0][i].set_position(upBorder,0,i);
    for (int i = 1; i < size_of_board+1; i++)
    {
        for (int j = 0; j <= size_of_board+1; j++)
        {
            if (j==0)
                hexCells[i][j].set_position(leftBorder,i,j);
            else if (j==size_of_board+1)
                hexCells[i][j].set_position(rightBorder,i,j);
            else
                hexCells[i][j].set_position(empty,i,j);

        }
    }
    for (int i = 0; i < size_of_board+2; i++)
    {
        hexCells[size_of_board+1][i].set_position(downBorder,size_of_board+1,i);
    }
    created=true;
}
void Hex::Cell::set_position(XorEmptyOrO situation,int letter,int digit)
{
    xeo=situation;
    letter_position=letter;
    digit_position=digit;
}
ostream& operator<<(ostream& out, Hex& a){
    Hex::Cell **tempPointer=a.gethexCells();
    out<<"  ";
    for (int t = 1; t <=a.size_of_board; t++)
    {
        if(t<=10)//İT İS FOR AESTHETİC :(
            out<<" "<<t;
        else
            out<<t;
        
    }
    out<<endl;
    char alphabet[]=" ABCDEFGHIJKLMNOPRSTUVYZ";
    for (int i = 0; i < a.getSize()+2; i++)
    {
        for (int k = 0; k < i; k++)
            out<<" ";
        if (i!=a.getSize()+1)
            out<<alphabet[i];
        for (int j=0; j<a.getSize()+2;j++)
        {
            if (tempPointer[i][j].getXoe()==x)
                out<<" X";
            else if (tempPointer[i][j].getXoe()==empty)
                out<<" *";
            else if(tempPointer[i][j].getXoe()==leftBorder||tempPointer[i][j].getXoe()==rightBorder)
                out<<"\\";
            else if (tempPointer[i][j].getXoe()==downBorder||tempPointer[i][j].getXoe()==upBorder)
                out<<"--";
            else
                out<<" O";
        }
        out<<endl;
    }
    return out;
}
void Hex::play()
{
    bool reached1=false;
    bool reached2=false;
    cout<<"Computer's move:"<<endl;
    turnX=false;
    if(hexCells[letter_moves[iter-1]][digit_moves[iter-1]+1].getXoe()==empty){
        hexCells[letter_moves[iter-1]][digit_moves[iter-1]+1].setXoe(o);
        control(o,99999,999999,999,999,letter_moves[iter-1],digit_moves[iter-1]+1,&reached1,&reached2,o);
        }
    else if(hexCells[letter_moves[iter-1]][digit_moves[iter-1]-1].getXoe()==empty){
        hexCells[letter_moves[iter-1]][digit_moves[iter-1]-1].setXoe(o);
        control(o,99999,999999,999,999,letter_moves[iter-1],digit_moves[iter-1]-1,&reached1,&reached2,o);
        }
    else if(hexCells[letter_moves[iter-1]-1][digit_moves[iter-1]+1].getXoe()==empty){
        hexCells[letter_moves[iter-1]-1][digit_moves[iter-1]+1].setXoe(o);
        control(o,99999,999999,999,999,letter_moves[iter-1]-1,digit_moves[iter-1]+1,&reached1,&reached2,o);
        }
    else if(hexCells[letter_moves[iter-1]+1][digit_moves[iter-1]+1].getXoe()==empty){
        hexCells[letter_moves[iter-1]+1][digit_moves[iter-1]+1].setXoe(o);
        control(o,99999,999999,999,999,letter_moves[iter-1]+1,digit_moves[iter-1]+1,&reached1,&reached2,o);
        }
    else if(hexCells[letter_moves[iter-1]-1][digit_moves[iter-1]-1].getXoe()==empty){
        hexCells[letter_moves[iter-1]-1][digit_moves[iter-1]-1].setXoe(o);
        control(o,99999,999999,999,999,letter_moves[iter-1]-1,digit_moves[iter-1]-1,&reached1,&reached2,o);
        }
    else if(hexCells[letter_moves[iter-1]+1][digit_moves[iter-1]-1].getXoe()==empty){
        hexCells[letter_moves[iter-1]+1][digit_moves[iter-1]-1].setXoe(o);
        control(o,99999,999999,999,999,letter_moves[iter-1]+1,digit_moves[iter-1]-1,&reached1,&reached2,o);
        }
        cout<<(*this);
        if(reached1==true&&reached2==true){
            cout<<"!!!Computer (O) wons the game!!!"<<endl;
            finished=true;//if someone wons it means game is finished
        }
}
void Hex::play(XorEmptyOrO whoseTurn)
{
    if(whoseTurn==x)
        turnX=true;
    else
        turnX=false;
    
    myAtoi();
}
void Hex::myAtoi()
{
    cout<<"Enter the move:"<<endl;
    char temp[20];
    cin>>temp;
    if(temp[0]=='S'&&temp[1]=='A'&&temp[2]=='V'&&temp[3]=='E')
    {
        char fileName[30];
        cin>>fileName;
        ofstream saveFile;
        saveFile.open(fileName);
        saveFile<<(*this);
        saveFile.close();
        continue_to_play=false;
    }
    else if(temp[0]=='L'&&temp[1]=='O'&&temp[2]=='A'&&temp[3]=='D')
    {
        char fileName[30];
        cin>>fileName;
        ifstream loadFile;
        loadFile.open(fileName);
        loadFile>>(*this);
        loadFile.close();
        continue_to_play=false;
    }
    else if(temp[0]=='U'&&temp[1]=='N'&&temp[2]=='D'&&temp[3]=='O'){
        (*this)--;
        continue_to_play=false;
        }
    else
    {   
        connected_temp=0;//don't forget make it zero at the beggining :) 
        bool reached1=false;
        bool reached2=false;
        while (!emptyTest(temp))
        {
            cout<<"Enter truely please."<<endl;
            cin>>temp;
        }
        pushTointArray(temp[0]);
        if(temp[2]!='\0')
            pushTointArray(((temp[1]-'0')*10+temp[2]-'0'));
        else{
            pushTointArray(temp[1]-'0');}
        if(turnX)
        {
            hexCells[letter_moves[iter]][digit_moves[iter]].setXoe(x);
            turnX=false;
        }
        else
        {
            hexCells[letter_moves[iter]][digit_moves[iter]].setXoe(o);
            turnX=true;
        }        
        ++iter;
        cout<<(*this);
        if(turnX){
            control(o,99999,999999,999,999,letter_moves[iter-1],digit_moves[iter-1],&reached1,&reached2,o);
            if(reached1&&reached2){
                cout<<"!!O wons the game!!"<<endl<<endl;
                finished=true;//if someone wins game is finished
                }
        }
        else{
            control(x,99999,999999,999,999,letter_moves[iter-1],digit_moves[iter-1],&reached1,&reached2,x);
            if(reached1&&reached2){
                cout<<"!!X wons the game!!"<<endl<<endl;
                finished=true;//if someone wins game is finished
                }
            }
            continue_to_play=true;
    }
}
void Hex::pushTointArray(int num)
{
    int*temp=new int[iter];
    for (int i = 0; i < iter; i++)
        temp[i]=digit_moves[i];
    digit_moves=new int[iter+1];
    for (int i = 0; i < iter; i++)
        digit_moves[i]=temp[i];
    digit_moves[iter]=num;
    delete[]temp;
}
void Hex::pushTointArray(char num)
{
    int realNum=num-'A'+1;
    int *temp=new int[iter];
    for (int i = 0; i < iter; i++)
        temp[i]=letter_moves[i];
    letter_moves=new int[iter+1];
    for (int i = 0; i < iter; i++)
        letter_moves[i]=temp[i];
    letter_moves[iter]=realNum;
    delete[]temp;  
}
bool Hex:: emptyTest(char temp[3])
{

    int charTester;
    int intTester;
    
    charTester=temp[0]-'A'+1;
    if(temp[2]!='\0')
        intTester=(temp[1]-'0')*10+temp[2]-'0';
    else
        intTester=temp[1]-'0';
    if (hexCells[charTester][intTester].getXoe()==empty)
        return true;
    else
        return false;       
}
Hex Hex::operator--()
{
    hexCells[letter_moves[iter-1]][digit_moves[iter-1]].setXoe(empty);
    if (turnX)
        turnX=false;
    else
        turnX=true;
    --iter;
}
Hex Hex::operator--(int)
{
    
    hexCells[letter_moves[iter-1]][digit_moves[iter-1]].setXoe(empty);
    if (turnX)
        turnX=false;
    else
        turnX=true;
    iter--;
}


ofstream& operator<<(ofstream&out ,Hex& current)
{
    out<<current.created<<" ";
    out<<current.connected_o<<" ";
    out<<current.connected_x<<" ";
    out<<current.player2<<" ";
    out<< current.getTurn()<<" ";
    out<<current.getSize()<<" ";
    out<<current.getiter()<<" ";
    for (int i = 0; i <current.getiter(); i++)
    {
        out<<current.letter_moves[i]<<" ";
    }for (int i = 0; i<current.getiter(); i++)
    {
        out<<current.digit_moves[i]<<" ";
    }for (int i = 0; i<current.getSize()+2; i++)
    {
        for (int j= 0;j<current.getSize()+2; j++)
        {
            out<<current.hexCells[i][j].getXoe()<<" ";
        }
    }   
    return out;
}
ifstream& operator>>(ifstream& in,Hex& current)
{
    in>>current.created;
    in>>current.connected_o;
    in>>current.connected_x;
    in>>current.player2;
    in>>current.turnX;
    int size;
    in>>current.size_of_board;
    current.hexCells=new Hex::Cell*[current.size_of_board+2];
    for (int i = 0; i <= current.size_of_board+2; i++)
    {
        current.hexCells[i]=new Hex::Cell[current.size_of_board+2];
    }
    in>>current.iter;
    current.letter_moves=new int [current.iter];
    current.digit_moves=new int [current.iter];
    for (int i = 0; i < current.iter; i++)
    {
        in>>current.letter_moves[i];
    }
    for (int i = 0; i < current.iter; i++)
    {
        in>>current.digit_moves[i];
    }
    for (int i = 0; i < current.size_of_board+2; i++)
    {

        for (int j = 0; j < current.size_of_board+2; j++)
        {
            int temp;
            in>>temp;
            current.hexCells[i][j].set_position(((XorEmptyOrO)temp),i,j);
        }
    }
    cout<<"LOAADDAAA\n";
    return in;
}
void Hex::control(XorEmptyOrO target,int previ,int prevj,int previ2,int prevj2,int j,int i,bool* reached1,bool *reached2,XorEmptyOrO forCount)
{//control controls(sizeof +2 works in here )
//+2 is the borders
    int border1,border2;
    if (target==x)
    {
        border1=leftBorder;
        border2=rightBorder;
    }
    else
    {
        border1=downBorder;
        border2=upBorder;
    }
    if (hexCells[j][i].getXoe()==target)
    {//every check means that x or o is connected so I can check connectets in here
        connected_temp++;
        if(forCount==o){
            if(connected_o<connected_temp){
                connected_o=connected_temp;}
                }
        else if(forCount==x){
            if (connected_x<connected_temp){
                connected_x=connected_temp;}
                }
        if (i-1!=previ&&i-1!=previ2)
            control(target,i,j,previ,prevj,j,i-1,reached1,reached2,forCount);
        if ((j+1!=prevj&&i!=previ)&&(j+1!=prevj2&&i!=previ2))
            control(target,i,j,previ,prevj,j+1,i,reached1,reached2,forCount);
        if (i+1!=previ&&i+1!=previ2)
            control(target,i,j,previ,prevj,j,i+1,reached1,reached2,forCount);
        if (j-1!=prevj&&j-1!=prevj2)
            control(target,i,j,previ,prevj,j-1,i,reached1,reached2,forCount);
        if ((j-1!=prevj&&i+1!=previ)&&(j-1!=prevj2&&i+1!=previ2))
            control(target,i,j,previ,prevj,j-1,i+1,reached1,reached2,forCount);
        if ((j+1!=prevj&&i-1!=previ)&&(j+1!=prevj2&&i-1!=previ2))
            control(target,i,j,previ,prevj,j+1,i-1,reached1,reached2,forCount);
        if (j+1!=prevj&&j+1!=prevj2)
            control(target,i,j,previ,prevj,j+1,i,reached1,reached2,forCount);
    }//if you reach border make them true
    if(hexCells[j][i].getXoe()==border1)
        *reached1=true;
    if (hexCells[j][i].getXoe()==border2)
        *reached2=true;
}
bool Hex::operator==(const Hex &temp)
{
    int fulled1(0);
    int fulled2(0);
    for (int i = 0; i < size_of_board+2; i++)
        for (int j= 0; j< size_of_board+2; j++)
            if (hexCells[i][j].getXoe()==x||hexCells[i][j].getXoe()==o)
                fulled1++;

    for (int i = 0; i < size_of_board+2; i++)
        for (int j= 0; j< size_of_board+2; j++)
            if (temp.hexCells[i][j].getXoe()==x||temp.hexCells[i][j].getXoe()==o)
                fulled2++;
        if (fulled1>fulled2)
            return true;
        return false;
        
}
Hex::Hex()
{
    finished=false;
    created=false;
    turnX=true;
    hexCells=nullptr;
    letter_moves=nullptr;
    digit_moves=nullptr;
    iter=0;
    connected_x=0;
    connected_o=0;
}
bool Hex::getScore()
{//score is counting when entering the control
//so it does not means the exact value (ıf there is 3 connected x x's score can be 16 )so ı decided it to make bool
//score logic is true if more cells connected score goes higher but it is not exact
    if(connected_x>connected_o)
        return true;
    return false;    
}
Hex::~Hex(){
    cerr<<"Destructor called"<<endl;
    if(hexCells!=nullptr)
    {
        for (int i = 0; i < size_of_board+2; i++)delete [] hexCells[i];
        delete[] hexCells;
    }
    if (letter_moves!=nullptr)
        delete[] letter_moves;
    if(digit_moves!=nullptr)
        delete[]digit_moves;
}
Hex::Hex(const Hex&other)
{
    
    connected_x=other.connected_x;
    connected_o=other.connected_o;
    turnX=other.turnX;
    created=other.created;
    player2=other.player2;
    size_of_board=other.size_of_board;
    hexCells=new Cell*[size_of_board+2];
    for (int i = 0; i < size_of_board+2; i++)
    {
        hexCells[i]=new Cell[size_of_board+2];
        for (int j = 0; j < size_of_board+2; j++)
        {
            hexCells[i][j].set_position(other.hexCells[i][j].getXoe(),i,j);
        }
    }
    iter=other.iter;
    letter_moves=new int[iter];
    digit_moves=new int[iter];
    for (int i = 0; i < iter; i++)
    {
        letter_moves[i]=other.letter_moves[i];
        digit_moves[i]=other.digit_moves[i];
    }
}
Hex:: Hex(int)
{
    cerr<<"You should not use this constructor"<<endl;
    cerr<<"There is no Constructor like Hex(int)"<<endl;
}
Hex& Hex::operator=(const Hex& other){

    connected_x=other.connected_x;
    connected_o=other.connected_o;
    turnX=other.turnX;
    created=other.created;
    player2=other.player2;
    size_of_board=other.size_of_board;
    hexCells=new Cell*[size_of_board+2];
    for (int i = 0; i < size_of_board+2; i++)
    {
        hexCells[i]=new Cell[size_of_board+2];
        for (int j = 0; j < size_of_board+2; j++)
        {
            hexCells[i][j].set_position(other.hexCells[i][j].getXoe(),i,j);
        }
    }
    iter=other.iter;
    letter_moves=new int[iter];
    digit_moves=new int[iter];
    for (int i = 0; i < iter; i++)
    {
        letter_moves[i]=other.letter_moves[i];
        digit_moves[i]=other.digit_moves[i];
    }
    return (*this);
}