#include "myLib.h"
#include<iostream>
int main()
{
    cout<<"Welcome the Hex Game. If you want to change game write MENU on play screen"<<endl;
    Hex*Games;
    int howManyGame;
    do{//take input while games are less than 6
        cout<<"How many games do you want to play?"<<endl;
        cin>>howManyGame;
    }while (howManyGame<6);
    Games=new Hex[howManyGame];
        //here I'm making the games
    auto choice=0;
    do{
        cout<<"Which game do you want to play(enter 0 or 1 or...)"<<endl;
        cout<<"Enter -1 to compare 2 game's played cell number"<<endl;
        cout<<"Enter -2 to Exit"<<endl;
        cout<<"Enter -3 for look some games Score(which have higher score? X or O)"<<endl;
        cin>>choice;
        if(choice>=0&&choice<howManyGame)
        {
            if(!Games[choice].getCreated())//If game is not created before make it
            {
                Games[choice].playGame();//Here I designing the game size or other thinks
                if (Games[choice].getFinished()){//if game not finished before
                    cout<<Games[choice];
                    cout<<"This game finished.Please try another game"<<endl;}
                else
                {
                    cout<<Games[choice];
                    if (Games[choice].get2PlayerNumber())//if it is 2 player
                    {
                        Games[choice].play(x);
                        if(Games[choice].getContinue())
                            Games[choice].play(o);
                    }
                    else{
                        Games[choice].play(x);
                        if(Games[choice].getContinue())
                            Games[choice].play();
                    }
                }
            }
            else{
                if (Games[choice].getFinished()){
                    cout<<Games[choice];
                    cout<<"This game finished.Please try another game"<<endl;
                    }
                else
                {
                    cout<<Games[choice];
                    if (Games[choice].get2PlayerNumber())
                    {
                        Games[choice].play(x);
                        if(Games[choice].getContinue())
                        Games[choice].play(o);
                    }
                    else{
                        Games[choice].play(x);
                        if(Games[choice].getContinue())
                        Games[choice].play();
                    }
                }
            }
        }
        else if (choice==-1)
        {
            int game1,game2;
            cout<<"Enter first game number:"<<endl;
            cin>>game1;
            cout<<"Enter second game number:"<<endl;
            cin>>game2;
            if(Games[game1]==Games[game2])
                cout<<"Your first game has much fulled cells"<<endl;
            else
                cout<<"Your second game has much fulled cells"<<endl;
        }
        else if(choice==-2)
            cout<<"See you soon"<<endl;
        else if (choice==-3)
        {
            int gameChoi;
            cout<<"Enter the game which you want to look at score:"<<endl;
            cin>>gameChoi;
            if (Games[gameChoi].getScore())
                cout<<"X has much score"<<endl;
            else
                cout<<"O has much score"<<endl;
        }
        else
            cout<<"You Entered wrong choice"<<endl;
        cout<<"There are "<<Games[choice].getGameNumbers()<<" games"<<endl;
    }while (choice!=-2); 
    if(Games[1].getCreated())
    {
        Hex x(Games[1]);
        cout<<x;
        cout<<"This is a copied constructor."<<endl;
    }if(Games[1].getCreated())
    {
        Hex x=Games[1];
        cout<<x;
        cout<<"This is a assigned constructor."<<endl;
    }
    delete [] Games;   
}