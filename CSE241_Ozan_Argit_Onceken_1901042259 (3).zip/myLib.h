#ifndef myLib
#define myLib
#include<iostream>
#include<fstream>
using namespace std;
enum XorEmptyOrO{
    //enumeration for board
    x=1,o,empty,leftBorder,rightBorder,upBorder,downBorder
};
class Hex{
    public:
        ~Hex();
        bool operator==(const Hex&);
        Hex();//default constructor
        explicit Hex(int);//it is only for make constructor (I have default and copy constructor)
        friend ostream& operator<<(ostream& out, Hex&);//this writes like cout<<Hex;
        friend ofstream& operator<<(ofstream&, Hex&);//this writes to file
        friend ifstream& operator>>(ifstream&,Hex&);//this reads from file
        Hex(const Hex&other);//copy constructor()
        Hex& operator=(const Hex&);//assignment operator
        class Cell;
        inline const int getSize(){return size_of_board;}
        inline Cell** gethexCells(){return hexCells;}
        inline const bool getTurn(){return turnX;} //gets whose turn
        inline const int getiter(){return iter;}//gets iter
        inline const bool getCreated(){return created;}
        inline const bool getFinished(){return finished;}
        inline bool get2PlayerNumber(){return player2;}
        inline int getGameNumbers(){return gameCount;}
        inline bool getContinue(){return continue_to_play;}//My games tries to take other input if user says load so I make these function
        void playGame();//triggers the create function
        void play(XorEmptyOrO);//play for user
        void play();//play for computer
        bool getScore();//pdf sad int but I can change it to int easily but I think bool is better option for which's score is better
    private://if I do not need functions on main I did they private
        static int gameCount;
        void control(XorEmptyOrO target,int previ,int prevj,int previ2,int prevj2,int j,int i,bool* reached1,bool *reached2,XorEmptyOrO forCount);
        //control function kind of same at 1 2 and 3rd game but I checked the score in control
        //if it can goes the next cell score goes high
        //I know I can add default options to the control but I copied it from previous homework.
        bool continue_to_play;
        Hex operator--();//Prefix undo
        Hex operator--(int);//Postfix undo
        int connected_x;//holds the score for x
        int connected_o;//holds the score for o
        int connected_temp;//holds temporary score for writing code easily
        bool turnX;//if turn on x it is true
        bool created;//if it is created
        bool finished;//if it is finished
        bool emptyTest(char arr[3]);//looks for is input empty(ok to put)
        bool player2;//if 2 player plays it is false
        int size_of_board;
        Cell **hexCells;
        int *letter_moves;//this is pop and push dynamic arrays for undo moves
        int *digit_moves;//letter_moves and digit_moves comes together and seems like D12
        int iter;//iter is iterative int for letter_moves and digit_moves dynamic arrays.
        void createBoard();//creates board and Dynamic hexCells
        void myAtoi();//if realises if it is LOAD SAVE UNDO or next move and calls needed function
        void pushTointArray(char );//if sended value is char pushes to letter_moves
        void pushTointArray(int);//if int sended pushes to int array
};
class Hex:: Cell{
    public:  
    inline XorEmptyOrO getXoe(){return xeo;}//returns whats in that cell x ,o or empty 
    inline void setXoe(XorEmptyOrO temp){xeo=temp;} //sets the situation
    void set_position(XorEmptyOrO,int,int);
        Cell(){//default constructor for Cell
            xeo=empty;
        }
    private:
        int letter_position;//User will enters like A5 so positionLetter will hold A in this case
        int digit_position;//if User enters A5 digit_position holds the 5
        XorEmptyOrO xeo;
};
#endif