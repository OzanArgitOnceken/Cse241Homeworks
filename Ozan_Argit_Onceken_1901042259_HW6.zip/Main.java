public class Main {
    public static void main(String[] args){
        ArrayList <Integer>a=new ArrayList<Integer>();
        LinkedList <Integer>l=new LinkedList<Integer>();
        HashSet<Integer>h=new HashSet<Integer>();
        a.add(1);
        a.add(2);
        a.add(3);
        System.out.println("This is ArrayList of integer:");
        a.print();
        l.add(10);
        l.add(20);
        l.add(30);
        System.out.println("This is LinkedList of integer:");
        l.print();
        a.addAll(l);
        System.out.println("This is ArrayList+LinkedList of integer:");
        a.print();
        h.add(100);
        h.add(200);
        h.add(300);
        System.out.println("This is HashSet of integer:");
        h.print();
        a.addAll(h);
        System.out.println("This is ArrayList+LinkedList+HashSet of integer:");
        a.print();
        System.out.println("Now removing 100 from ArrayList+LinkedList+HashSet of integer:");
        a.remove(100);
        a.print();
        if(a.contains(200))
            System.out.println("This List contains 200 the integer");
        else
            System.out.println("This List did not contains 200 the integer");
        if(a.containsAll(l))
            System.out.println("This ArrayList contains the LinkedList");
        else
            System.out.println("This ArrayList not contains the LinkedList");
        System.out.println("Now removing the HashSet");
        a.removeAll(h);
        a.print();
        System.out.println("Now ArrayList retains only the LinkedList");
        a.retainAll(l);
        a.print();
        System.out.println("Now removing all of datas from ArrayList");
        a.clear();
        a.print();
        if(a.isEmpty())
            System.out.println("This array is empty");
        else
            System.out.println("This array is not empty");     
        LinkedList<String>LinkedString=new LinkedList<String>();
        LinkedString.offer("This");
        LinkedString.offer("is a");
        LinkedString.offer("String of");
        LinkedString.offer("LinkedList");
        LinkedString.add("datas");
        LinkedString.print();
        System.out.println("This is first element of LinkedList: "+LinkedString.element());
        LinkedString.poll();
        System.out.println("This is first element of LinkedList: "+LinkedString.element());
        LinkedString.poll();
        System.out.println("This is first element of LinkedList: "+LinkedString.element());
        LinkedString.poll();
        System.out.println("This is first element of LinkedList: "+LinkedString.element());
        LinkedString.poll();
        System.out.println("This is first element of LinkedList: "+LinkedString.element());
        LinkedString.poll();
        LinkedString.poll();
    }
}