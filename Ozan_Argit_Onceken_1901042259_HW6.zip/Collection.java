/**
 * <h1>Collection</h2>
 * This is the interface class<br>
 * <b>Note:</b>I will explain all methods later
 */
public interface Collection<E>{
	/**
	 * @return It returns an iterator(iterator's datas are equals with the sended one)
	 */
	public Iterator<E> iterator();
	/**
	 * @param e e is the parameter that will adding at the end of the array
	 */
	public void add(E e);
	/**
	 * @param c c is a Collection class that is sended
	 * this method adds the sended class to this class
	 */
	public void addAll(Collection<E> c);
	/**
	 * Clears the datas makes the size of array 0
	 */
	public void clear();
	/**
	 * 
	 * @param e parameter e is the data which method searchs for
	 * @return if it founds the sended data method returns true else it returns false
	 */
	public boolean contains(E e);
	/**
	 * @param c c is the Object that is sended 
	 * @return it returns true this object contains all of the sended else it returns false
	 */
	public boolean containsAll(Collection<E> c);
	/**
	 * Returns true
	 * @return if it is 0(size of array=0) it returns true else it returns false
	 */
	public boolean isEmpty();
	/**
	 * This method removes the sended generic data
	 * @param e e is the sended Generic data
	 */
	public void remove(E e);
	/**
	 * This method removes the sended objects all data
	 * @param c c is the object
	 */
	public void removeAll(Collection<E> c);
	/**
	 * This method makes the data of all sended data retain 
	 * @param c c is the object that is sende to method
	 */
	public void retainAll(Collection<E> c);
	/** 
	 * Returns the Size of data
	 * @return This method returns the size of Object
	 */
	public int size();
	/**
	 * This prints the generic datas
	 */
	public void print();
}
