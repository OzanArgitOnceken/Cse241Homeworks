/**
 * <h1> Iterator Class </h1>
 * The iterator's task is moving in the array
 * @author Ozan Argıt Önçeken
 * @since 25.01.2021
 */
public class Iterator <E>{
	E  data[];
	private int iter;
	/**
	 * 
	 * @param tempData it is the sended Data list for Iterator
	 */
	public Iterator(E[] tempData){
        data= tempData;
        iter=-1;        
	}
	/**
	 * if iterator reaches the end it makes iterator -1 again
	 * @return if tempData has next iterator it returns true else returns false
	 */
	public boolean hasNext() {
		if(iter+1>=data.length){
			iter=-1;
			return false;
		}
		return true;
	}
	/**
	 * This method increases the iter and if it has no next it stopst checking
	 * @return if there is no next data it returns null else it returns the data
	 */
	public E next() {
		if(!hasNext()){
			iter=-1;
			return null;
		}
		else{
			++iter;
			return data[iter];
		}
	}
	/**
	 * it removes the last returned (iterator will always)
	 */
	public void remove() {
		while(hasNext()){
			data[iter]=next();
		}
		data[iter]=null;
	}
}