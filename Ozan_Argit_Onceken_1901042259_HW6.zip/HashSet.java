public class HashSet<E> implements Set<E>{
    
	E myArray[];
	int size_of_data;
	HashSet(){
		size_of_data=0;
	}
	@Override
	public Iterator<E> iterator() {
		Iterator <E>a=new Iterator<E>(myArray);
		return a;
	}
	@Override
	@SuppressWarnings("unchecked")
	public void add(E e){
		E temporary_for_add[]=(E[]) new Object [size()];
		for (int i = 0; i < size(); i++){
			temporary_for_add[i]=myArray[i];
		}
		myArray=(E[]) new Object [size()+1];
		for (int i = 0; i <size(); i++) {
			myArray[i]=temporary_for_add[i];
		}
		myArray[size()]=e;
		size_of_data++;
	}

	@Override
	public void addAll(Collection<E> c) {
		E temp;
		Iterator<E> tempIterator=c.iterator();
		while(tempIterator.hasNext())
		{
			temp=tempIterator.next();
			add(temp);
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public void clear() {
		myArray=(E[])new Object[0];
		size_of_data=0;
		System.out.println("All datas have been removed");
	}

	@Override
	public boolean contains(E e) {
		for (int i = 0; i <size(); i++){
			if(myArray[i]==e)
				return true;//if code founds returns it immediately
		}
		return false;//if it can not founds returns false
	}

	@Override
	public boolean containsAll(Collection<E> c) {
		int all_Element_Size=0;
		Iterator<E> tempIterator=c.iterator();
		for (int i = 0; i < size(); i++) {
			while(tempIterator.hasNext()){//if it founds makes all_element_size variable ++
				if(myArray[i]==tempIterator.next()){
					all_Element_Size++;
				}
			}
		}//if all_elements_size varianle equals c.size it means all elements includes in this 
		if(all_Element_Size==c.size())//so I can return true
			return true;
		return false;//else I will return false
	}

	@Override
	public boolean isEmpty() {
		return(size()==0?true:false);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void remove(E e) {
		int tempİterator=0;
		E temp[]=(E[])new Object [size()-1];
		for (int i = 0; i < size(); i++){
			if(myArray[i]!=e){
				temp[tempİterator]=myArray[i];
				tempİterator++;
			}
		}
		myArray=temp;
		size_of_data--;
	}

	@Override
	public void removeAll(Collection<E> c) {
		E temp;
		Iterator<E> tempIterator=c.iterator();
		while(tempIterator.hasNext()){
			temp=tempIterator.next();
			for (int i = 0; i < size();i++) {
				if(myArray[i]==temp)
					remove(temp);
			}
		}
		
	}

	@Override
	public void retainAll(Collection<E> c) {
		E temp;
		Iterator<E> tempIterator=c.iterator();
		for (int i = 0; i < size(); i++){
			boolean ok_to_remove=true;//at the beggining it is ok to remove
			while(tempIterator.hasNext())
			{
				temp=tempIterator.next();
				if(myArray[i]==temp)//if they are same, do not remove.
					ok_to_remove=false;
			}
			if(ok_to_remove){
				remove(myArray[i]);
				i--;
				//I'm decreasing i because the size is decreasing and if I do not decrease i
				//i can jump the next one of the array
			}
		}
	}

	@Override
	public int size() {
		return size_of_data;
	}
	@Override
	public void print() {
		for (int i = 0; i < size(); i++) {
			System.out.println(myArray[i]);
		}
	}
}
