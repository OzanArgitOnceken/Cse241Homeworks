public interface Queue <E> extends Collection<E>{
    void add(E e);
    E element();
    void offer(E e);
    E poll();
}
