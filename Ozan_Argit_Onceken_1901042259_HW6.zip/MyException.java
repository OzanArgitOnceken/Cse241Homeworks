
public class MyException extends Exception{
    public MyException(){
        super("Something goes wrong");
    }
    public MyException(String message){
        super(message);
    }
}
