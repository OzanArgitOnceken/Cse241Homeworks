#include "myLib.h"
int Hex::gameCount=0;
int Hex::fulledCells=0;
void Hex::Cell::set_Position(XorEmptyOrO newXOE,int letter,int digit)
{//in this function I am setting the positions and X or O or Empty
    letter_position=letter;
    digit_position=digit;
    xeo=newXOE;
    if (newXOE==x||newXOE==o)
        fulledCells++;
}
void Hex::playGame()
{//creating the function
    ++gameCount;//in this function we are literally creating a game so I can increase gameCount
    created_before=true;//now it is created
    do
    {
        cout<<"Enter the size:(size should be greater than 5)"<<endl;
        cin>>size_of_board;
    } while (!(size_of_board>5));
    cout<<"2 Player?(Y/N)"<<endl;
    char temp;
    cin>>temp;
    temp=='Y'?player2=true:player2=false;
    makeBoard();
}
void Hex::makeBoard()
{//making the board
    hexCell.resize(size_of_board+2);
    for (int i = 0; i < size_of_board+2; i++)
    {
        Cell emptyTempCell;
        hexCell[i].resize(size_of_board+2);
        emptyTempCell.set_Position(leftBorder,i,0); 
        hexCell[i][0]=emptyTempCell;
        for (int j = 1; j < size_of_board+2; j++)
        {
            if(i==0){emptyTempCell.set_Position(upBorder,0,j);
                hexCell[i][j]=emptyTempCell;
                }
            else if (i==size_of_board+1)
                {   
                    emptyTempCell.set_Position(downBorder,size_of_board+1,j);
                    hexCell[i][j]=emptyTempCell;
                }
            else{
                emptyTempCell.set_Position(empty,i,j);
                hexCell[i][j]=emptyTempCell;
                }
        } 
        emptyTempCell.set_Position(rightBorder,i,size_of_board+1);  
                hexCell[i][size_of_board+1]=emptyTempCell;
    }

}
void Hex::printBoard()
{//printboard reads and prints the board
    cout<<"   ";
    char alphabet[]={"ABCDEFGHIJKLMNOPQRSTUVWXYZ"};//it is for up
    for (int i = 0; i < size_of_board; i++)
    {
        cout<<alphabet[i]<<" ";
    }
    
    for (int i = 0; i < size_of_board+2; i++)
    {
        cout<<endl;
        for (int k = 0; k< i; k++)
        {
            cout<<" ";
        }
        if(i!=size_of_board+1&&i!=0&&i<10)
            cout<<i<<" ";
        else if(i!=size_of_board+1&&i!=0&&i>=10)
            cout<<i;
        else
            cout<<"  ";
        cout<<"\\";
        for (int j = 0; j < size_of_board+2; j++)
        {   
            if(hexCell[i][j].get_Position()==empty)
                cout<< "* ";   
            else if (hexCell[i][j].get_Position()==upBorder)
                cout<<"--";   
            else if (hexCell[i][j].get_Position()==x)
                cout<<"X ";  
            else if (hexCell[i][j].get_Position()==o)
                cout<<"O ";   
            else if (hexCell[i][j].get_Position()==downBorder)
                cout<<"--";   
        }
                cout<<"\\"; 
    }
    cout<<endl;
}
void Hex::play(XorEmptyOrO target)
{//it is playing function 
    bool reached1=false;
    bool reached2=false;
    int i,j;
    do
    {
        cout<<"Player X's turn:"<<endl<< "Player should enter coordinates true"<<endl;
        myAtoi(&i,&j);
    }while (hexCell[j][i].get_Position()!=empty);
    hexCell[j][i].set_Position(target,i,j);
    printBoard();
    control(target,99999,999999,999,999,j,i,&reached1,&reached2);
    if(reached1&&reached2)
    {
        cout<<"!!!PLAYER"<<target<<" WON THE GAME!!!"<<endl;
        finished=true;
    }
    last_i=i;
    last_j=j;
}
void Hex::play()
{//it is playing function with computer
    bool reached1=false;
    bool reached2=false;
    cout<<"Computer's move:"<<endl;
    int i,j;
    if (hexCell[last_j][last_i+1].get_Position()==empty)
    {
        hexCell[last_j][last_i+1].set_Position(o,last_j,last_i+1);
        j=last_j;
        i=last_i+1;
    }
    else if (hexCell[last_j][last_i-1].get_Position()==empty)
    {
        hexCell[last_j][last_i-1].set_Position(o,last_j,last_i-1);
        j=last_j;
        i=last_i-1;
    }
    else if (hexCell[last_j-1][last_i-1].get_Position()==empty)
    {
        hexCell[last_j-1][last_i-1].set_Position(o,last_j-1,last_i-1);
        j=last_j-1;
        i=last_i-1;
    }
    else if (hexCell[last_j-1][last_i+1].get_Position()==empty)
    {
        hexCell[last_j-1][last_i+1].set_Position(o,last_j-1,last_i+1);
        j=last_j-1;
        i=last_i+1;
    }
    else if (hexCell[last_j+1][last_i-1].get_Position()==empty)
    {
        hexCell[last_j+1][last_i-1].set_Position(o,last_j+1,last_i-1);
        j=last_j+1;
        i=last_i-1;
    }
    else if (hexCell[last_j-1][last_i+1].get_Position()==empty)
    {
        hexCell[last_j-1][last_i+1].set_Position(o,last_j-1,last_i+1);
        j=last_j-1;
        i=last_i+1;
    }
    else{
        i=0;
        j=0;
        while (hexCell[i][j].get_Position()!=empty)
        {
            i++;
            j++;
        }
        hexCell[i][j].set_Position(o,i,j);   

    }
    
    control(o,99999,999999,999,999,j,i,&reached1,&reached2);
    cout<<reached1<<reached2<<endl; 
    printBoard();
    if(reached1&&reached2)
    {
        cout<<"!!!COMPUTER WON THE GAME!!!"<<endl;
        finished=true;
    }
    last_i=i;
    last_j=j;
}
void Hex::myAtoi(int *i,int *j)
{//myatoi controls if it is movement command save or load
    string command;
    cin>>command;
    if(command[0]=='S'&&command[1]=='A'&&command[2]=='V'&&command[3]=='E')
    {
        char name[50];
        cin>>name;
        saveGame(name);
    }
    else if(command[0]=='L'&&command[1]=='O'&&command[2]=='A'&&command[3]=='D')
    {
        char name[50];
        cin>>name;
        loadGame(name);
    }
    else{
        *i=command[0]-'A'+1;
        if(command[2]!='\0'){
            *j=(command[1]-'0')*10+(command[2]-'0');}
        else
            *j=command[1]-'0';}
}
void Hex::control(XorEmptyOrO target,int previ,int prevj,int previ2,int prevj2,int j,int i,bool* reached1,bool *reached2)
{//control controls(sizeof +2 works in here )
//+2 is the borders
    int border1,border2;
    if (target==x)
    {
        border1=leftBorder;
        border2=rightBorder;
    }
    else
    {
        border1=downBorder;
        border2=upBorder;
    }
    if (hexCell[j][i].get_Position()==target)
    {
        if (i-1!=previ&&i-1!=previ2)
            control(target,i,j,previ,prevj,j,i-1,reached1,reached2);
        if ((j+1!=prevj&&i!=previ)&&(j+1!=prevj2&&i!=previ2))
            control(target,i,j,previ,prevj,j+1,i,reached1,reached2);
        if (i+1!=previ&&i+1!=previ2)
            control(target,i,j,previ,prevj,j,i+1,reached1,reached2);
        if (j-1!=prevj&&j-1!=prevj2)
            control(target,i,j,previ,prevj,j-1,i,reached1,reached2);
        if ((j-1!=prevj&&i+1!=previ)&&(j-1!=prevj2&&i+1!=previ2))
            control(target,i,j,previ,prevj,j-1,i+1,reached1,reached2);
        if ((j+1!=prevj&&i-1!=previ)&&(j+1!=prevj2&&i-1!=previ2))
            control(target,i,j,previ,prevj,j+1,i-1,reached1,reached2);
        if (j+1!=prevj&&j+1!=prevj2)
            control(target,i,j,previ,prevj,j+1,i,reached1,reached2);
    
    }//if you reach border make them true
    if(hexCell[j][i].get_Position()==border1)
        *reached1=true;
    if (hexCell[j][i].get_Position()==border2)
        *reached2=true;
}
void Hex::saveGame(char *name)
{//it is saving what we need
    cerr<<"Saving the file"<<endl;
    ofstream savingFile;
    savingFile.open(name);
    savingFile<<size_of_board<<endl;
    savingFile<<player2;
    for (int i = 0; i <size_of_board+2; i++)
    {
        for (int j = 0; j < size_of_board+2; j++)
        {
           savingFile<<hexCell[i][j].get_Position();
        }   
    }  
}
void Hex::loadGame(char*name)
{
    ifstream loaded;
    loaded.open(name);
    if(!loaded.is_open())
        cerr<<"There is no file named: "<<name<<endl;
    else{
        loaded>>size_of_board;
        cout<<size_of_board<<endl;
        char tempChar;
        hexCell.resize(size_of_board+2);
        loaded>>tempChar;
        player2=tempChar;
        for (int i = 0; i <size_of_board+2; i++)
        {
            hexCell[i].resize(size_of_board+2);
            for (int j = 0; j < size_of_board+2 ; j++)
            {
                if(hexCell[i][j].get_Position()==x||hexCell[i][j].get_Position()==o)
                    fulledCells--;//we will change this if it is x or o or empty
                loaded>>tempChar;
                int tempEnum;
                tempEnum=tempChar-'0';
                hexCell[i][j].set_Position((XorEmptyOrO)tempEnum,j,i);
            }
        }
    }
   printBoard();
}
Hex::Hex(bool created){//it is a constructor and it makes ready to playGame function
    created_before=created;
    finished=false;
}
Hex::Hex(){//if I delete this compiler gives error so I make it an error constructor(it should not be used)
    cerr<<"There is no constructor like Hex()"<<endl;
}
Hex::Hex(int a){//I have to make 3 constructor but I do not really need it
    cerr<<"There is no constructor like Hex(int "<<a<<")"<<endl;
}
bool Hex::compareTest(Hex compared)
{//compare 2 board and return true if current has more pointed cells
    int tested1=pointedCell();
    int tested2=0;
    for (int i = 0; i < compared.getSize()+2; i++)
    {
        for (int j = 0; j < compared.getSize()+2; j++)
        {
            if (hexCell[i][j].get_Position()==x||hexCell[i][j].get_Position()==o)
                tested2++;
        }
    }
    return(tested1>tested2?true:false);
}
int Hex::pointedCell()
{//it is returns how many pointed cells in that board
    int tested1=0;
    for (int i = 0; i < size_of_board+2; i++)
    {
        for (int j = 0; j < size_of_board+2; j++)
        {
            if (hexCell[i][j].get_Position()==x||hexCell[i][j].get_Position()==o)
                tested1++;
        }
    }
    return tested1;
}