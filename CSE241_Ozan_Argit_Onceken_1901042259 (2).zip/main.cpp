#include "myLib.h"
int main()
{
    cout<<"Welcome the Hex Game. If you want to change game write MENU on play screen"<<endl;
    vector<Hex>Games;
    int howManyGame;
    do{//take input while games are less than 6
        cout<<"How many games do you want to play?"<<endl;
        cin>>howManyGame;
    }while (howManyGame<6);

    for (int i = 0; i < howManyGame; i++)
        Games.push_back(Hex(false));
        //here I'm making the games
    int choice=0;
    do{
        cout<<"Which game do you want to play(enter 0 or 1 or...)"<<endl;
        cout<<"Enter -1 to compare 2 game's played cell number"<<endl;
        cout<<"Enter -2 to Exit"<<endl;
        cin>>choice;
        if(choice>=0&&choice<howManyGame)
        {
            if(!Games[choice].getCreated())//If game is not created before make it
            {
                Games[choice].playGame();//Here I designing the game size or other thinks
                if (Games[choice].getFinished()){//if game not finished before
                    Games[choice].printBoard();
                    cout<<"This game finished.Please try another game"<<endl;}
                else
                {
                    Games[choice].printBoard();
                    if (Games[choice].get2PlayerNumber())//if it is 2 player
                    {
                        Games[choice].play(x);
                        Games[choice].play(o);
                    }
                    else{
                        Games[choice].play(x);
                        Games[choice].play();
                    }
                }
            }
            else{
                if (Games[choice].getFinished()){
                    Games[choice].printBoard();
                    cout<<"This game finished.Please try another game"<<endl;
                    }
                else
                {
                    Games[choice].printBoard();
                    if (Games[choice].get2PlayerNumber())
                    {
                        Games[choice].play(x);
                        Games[choice].play(o);
                    }
                    else{
                        Games[choice].play(x);
                        Games[choice].play();
                    }
                }
            }
        }
        else if (choice==-1)
        {
            int game1,game2;
            cout<<"Enter first game number:"<<endl;
            cin>>game1;
            cout<<"Enter second game number:"<<endl;
            cin>>game2;
            if(Games[game1].compareTest(Games[game2]))
                cout<<"Game 1 has much pointed cells"<<endl;
            else
                cout<<"Game 1 has much pointed cells"<<endl;
        }
        else if(choice==-2)
            cout<<"See you soon"<<endl;
        else
            cout<<"You Entered wrong choice"<<endl;
        cout<<"There are "<<Games[choice].getGameNumbers()<<" Games and "<<Games[choice].getFulledCells()<<" pointed cells."<<endl;
    }while (choice!=-2);    
}