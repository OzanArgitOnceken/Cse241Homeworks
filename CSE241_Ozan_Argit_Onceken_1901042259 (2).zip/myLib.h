
#ifndef myLib
#define myLib
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
using namespace std;
enum XorEmptyOrO{
    //enumeration for board
    x=1,o,empty,leftBorder,rightBorder,upBorder,downBorder
};
class Hex
{
    private://these are private fonctions
        bool created_before;
        class Cell;
        int size_of_board;
        bool player2;
        bool finished;
	    vector<vector<Cell>>hexCell;
        int last_i,last_j;//it is for make easy computer's move
        static int gameCount;
        static int fulledCells;
    public:
        //I will explain all functions in their inside
        Hex(bool);
        Hex(int);
        Hex();
        inline bool getCreated(){return created_before;}//inline functions for easy returned values
        inline bool getFinished(){return finished;}
        inline bool get2PlayerNumber(){return player2;}
        inline static int getGameNumbers(){return gameCount;}
        inline static int getFulledCells(){return fulledCells;}
        inline int getSize(){return size_of_board;}
        void playGame();
        void saveGame(char []);
        void loadGame(char []);
        int pointedCell();
        bool compareTest(Hex);
        void play(XorEmptyOrO);
        void play();
        void control(XorEmptyOrO,int,int,int ,int,int ,int ,bool*,bool*);
        void myAtoi(int *i,int *j);
        void makeBoard();
        void printBoard();
};
class Hex::Cell{
    private:
    int letter_position;//User will enters like A5 so positionLetter will hold A in this case
    int digit_position;//this will hold the digit of input
    XorEmptyOrO xeo;//X or empty or O
    public:
    void set_Position(XorEmptyOrO,int,int);//it is looks like a constructor
    inline XorEmptyOrO get_Position(){return xeo;}//this returns x or o or empty
};
#endif