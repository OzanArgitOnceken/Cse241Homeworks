
#include<iostream>
#include<vector>
#include<fstream>
#include<deque>
using namespace std;
enum XorEmptyOrO{
   //enumeration for board
   x=1,o,empty,leftBorder,rightBorder,upBorder,downBorder
};
class AbstractHex{
   public:
   AbstractHex();
   class Cell;
   void setSize();
   void myAtoi();
   virtual void operator()(int,int=0)=0;
   inline const int getSize(){return size_of_board;}
   private:
       int size_of_board;
       void easyAtoi();
       bool turn_of_X;
       int last_Of_X;
       int last_Of_Y;
   protected:
   int flag1,flag2;
        virtual void control(int,int,XorEmptyOrO)=0;        
       virtual bool operator==( AbstractHex&)=0;
       virtual void reset()=0;
       inline bool isEnd(){return finished;}
       int number_of_moves;
       virtual string lastMove()=0;
       bool finished;
       bool player_2;
       inline void setSizeWhileReadingFromFile(int sented_integer){size_of_board=sented_integer;}
       int temporary_x,temporary_y;
       inline int getLastX(){return last_Of_X;}
       inline int getLastY(){return last_Of_Y;}
       inline void setLastY(int which_I_Send){last_Of_Y=which_I_Send;}
       void setXAndY(int,int);
       inline bool isTurnOfX(){return turn_of_X;}
       inline bool setTurnOfX(bool a){turn_of_X=a;}
       virtual void createBoard()=0;
       inline int numberOfMoves(){return number_of_moves;};
       virtual void print()=0;
       virtual void play(int,int,XorEmptyOrO)=0;
       virtual void play()=0;
       virtual void writeToFile()=0;
        virtual void readFromFile()=0;
};
class AbstractHex::Cell{
   public:
       inline XorEmptyOrO getXoe(){return xeo;}//returns whats in that cell x ,o or empty 
       inline void setXoe(XorEmptyOrO temp){xeo=temp;} //sets the situation
       void set_position(XorEmptyOrO,int,int);
           Cell(){//default constructor for Cell
               xeo=empty;
           }
   protected:
       int letter_position;//User will enters like A5 so positionLetter will hold A in this case
       int digit_position;//if User enters A5 digit_position holds the 5
       XorEmptyOrO xeo;
};
class myException: public exception
{
   public:
       myException(string temp){message=temp;};
       myException(){message="Something wrong but did not specified.";}
       string getSpecifiedException() const throw(){
           return message;
       }
       const char* what() const throw() override
       {
         return "Something goes wrong";
       }
   private:
       string message;
};
namespace Array{
    class HexArray1D:public AbstractHex{
        public:
            HexArray1D();
            ~HexArray1D();
            void readFromFile();
            string lastMove()override;
            void createBoard()override;
            void print()override;
            bool operator==( AbstractHex&)override;
            void reset()override;
            Cell* array_of_1D;
        private:
            void operator()(int,int)override;
            void play(int,int,XorEmptyOrO)override;
            void play()override;
            void writeToFile()override;
            void control(int,int,XorEmptyOrO)override;
    };
}
namespace VectorHex{
    class HexVector:public AbstractHex{
        public:
            HexVector();
            void reset();
            vector<vector<Cell>>board_of_hex;
            string lastMove()override;   
            void print()override;
            bool operator==( AbstractHex&)override;
        private:
            void operator()(int,int)override;
            void readFromFile();
            void play(int,int,XorEmptyOrO)override;
            void play()override;
            void createBoard()override;
            void writeToFile()override;
            void control(int,int,XorEmptyOrO)override;
    };
}
namespace Adapter{
    template <template <class K,class Alloc = allocator<K>> class T>
    class HexAdapter:public AbstractHex{
        public:
            HexAdapter();
            void reset();
            T<T<Cell>> board_of_hex;
            string lastMove()override;   
            void print()override;
            bool operator==( AbstractHex&)override;
        private:
            void operator()(int,int)override;
            void readFromFile();
            void play(int,int,XorEmptyOrO)override;
            void play()override;
            void createBoard()override;
            void writeToFile()override;
            void control(int,int,XorEmptyOrO)override;
    };
}
bool global( AbstractHex&);
using namespace VectorHex;
using namespace Adapter;
using namespace Array;
int main()
{
    //I do not decide the main decide so you can test which you want
    //if you want to create a object you should run the setSize method first
    //for making moves you should ryun myAtoi method
    //for see what you have done you should run print method
    int howManyMoves;
    cout<<"Enter how many moves you want to do with HexVector";
    cin>>howManyMoves;
    HexVector b;
    b.setSize();
    b.print();
    b.myAtoi();
    b.reset();//here I am showing to reset.
    int i(0);
    b.print();
    while(i<howManyMoves){
        b.myAtoi();
        b.print();
    i++;
    }
    HexArray1D ar1d;
    i=0;
    ar1d.setSize();
    while(i<howManyMoves){
        cout<<"s"<<endl;
        ar1d.myAtoi();
        ar1d.print();
        i++;
    }
    HexAdapter<vector>VecAdapter;
    VecAdapter.setSize();
    i=0;
    while(i<howManyMoves){
        VecAdapter.myAtoi();
        VecAdapter.print();
        i++;
    }
    i=0;
    HexAdapter<deque>DequeAdapter;
    DequeAdapter.setSize();
    while(i<howManyMoves){
        DequeAdapter.myAtoi();
        DequeAdapter.print();
        i++;
    }
    HexVector c;
    c.setSize();
    c.print();
    try
    {
        cout<<c.lastMove();
    }
    catch(string e )
    {
        cerr << e<<'\n';
    }
    HexVector x;
    x.setSize();
    x.print();
    x.myAtoi();
    HexVector y;
    y.setSize();
    y.print();
    y.myAtoi();
    if(x==y)
        cout<<"they are same"<<endl;
    return 0;
}
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>::reset(){
    for (int i = 0; i < getSize()+2; i++)
        board_of_hex[i].resize(0);
    board_of_hex.resize(0);
    setSizeWhileReadingFromFile(0);
    setTurnOfX(true);
    setLastY(-1);
    finished=false;
    number_of_moves=0;
    setSize();
}
template <template <typename K,class Alloc = allocator<K>> class T>
string HexAdapter<T>::lastMove(){
    if(getLastY()<0)
        throw (myException());
    char temp[3];
    temp[0]=getLastX()+'A'-1;
    if (getLastY()>9)
    {
        temp[1]=(getLastY()/10)+'0';
        temp[2]=(getLastY()%10)+'1'-1;
    }
    else
        temp[1]=getLastY()+'1'-1;    
    return temp;    
}   
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>::print(){
    for (int i = 0; i < AbstractHex::getSize()+2; i++)
    {
        for (int k = 0; k < i; k++)
        {
            cout<<" ";
        }
        for (int j = 0; j < AbstractHex::getSize()+2; j++)
        {
            if (board_of_hex[i][j].getXoe()==upBorder)
                cout<<"--";
            else if (board_of_hex[i][j].getXoe()==rightBorder)
                cout<<"\\";
            else if (board_of_hex[i][j].getXoe()==leftBorder)
                cout<<"\\";
            else if (board_of_hex[i][j].getXoe()==downBorder)
                cout<<"--";
            else if (board_of_hex[i][j].getXoe()==x)
                cout<<"X ";
            else if (board_of_hex[i][j].getXoe()==o)
                cout<<"O ";
            else
                cout<<"* ";
        }
    cout<<endl;
    }
}
template <template <typename K,class Alloc = allocator<K>> class T>
bool HexAdapter<T>:: operator==( AbstractHex&temp){
    if(this->getSize()!=temp.getSize())
        return false;
    for (int i = 0; i < getSize()+2; i++)
    {
        for (int j = 0; j < getSize()+2;j++)
        { 
            try
            {
                if (board_of_hex[i][j].getXoe()!=empty)//if there is extra 1 parameter
                    temp.operator()(i,j);//I can add XorEmptorO and check it much nicer
            }
            catch(const myException& e)
            {
                cerr << e.getSpecifiedException() << endl;
                    return false;
            }
        }
    }
    return true;
}
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>::operator()(int row,int column){
    if (board_of_hex[row][column].getXoe()==empty)
        throw(myException("Empty cell detected,boards are different"));
}
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>:: readFromFile(){
    string name_of_file;
    cin>>name_of_file;
    fstream file;
    file.open(name_of_file,ios::in);
    int temp;
    file>>temp;
    setSizeWhileReadingFromFile(temp);
    file>>number_of_moves;
    file>>finished;
    file>>player_2;
    board_of_hex.resize(getSize()+2);
    for (int i = 0; i < getSize()+2; i++)
        board_of_hex[i].resize(getSize()+2);
    for (int i = 0; i < getSize()+2; i++)
    {
        for (int j = 0; j < getSize()+2; j++)
        {
            file>>temp;
            board_of_hex[i][j].setXoe((XorEmptyOrO)temp);
        }
    }
    file.close();
}
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>::play(int a,int b,XorEmptyOrO xo){
    if(board_of_hex[a+1][b+1].getXoe()==empty){
        number_of_moves++;
        board_of_hex[a+1][b+1].set_position(xo,a+1,b+1);
        setXAndY(a+1,b+1);
        this->print();
        if(this->isTurnOfX()==true){
            this->setTurnOfX(false);
                myAtoi();
            }
        else
            setTurnOfX(true);
        }
    else
    {
        cout<<"The place is filled before. Please enter a new command"<<endl;
        myAtoi();
    }
}
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>::play(){
    //algorithm is play the user's command if it is true 
    //if it is not true send back to myAtoi function
    //if next cell is empty put the o on it 
    //if it is not empty put the first place at you find 
    bool continue_to_put_computers_move=true;
    if(board_of_hex[temporary_x+1][temporary_y+1].getXoe()==empty)
        board_of_hex[temporary_x+1][temporary_y+1].setXoe(x);
    else{
            cout<<"You entered wrong coordinates"<<endl<<"Please enter again"<<endl;
            myAtoi();
            continue_to_put_computers_move=false;
        }
    if(continue_to_put_computers_move){

        this->print();
        cout<<"Now Computer making the move"<<endl;
        if(board_of_hex[temporary_x+1][temporary_y+2].getXoe()==empty)
            board_of_hex[temporary_x+1][temporary_y+2].setXoe(o);
        else
        {
            int a(0),b(0);
            while (board_of_hex[a][b].getXoe()!=empty)
            {
                a++;
                b++;
            }
               board_of_hex[a][b].setXoe(o);
        }
        this->print();
    }
    cout<<endl;
}
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>:: createBoard(){
    board_of_hex.resize(AbstractHex::getSize()+2);
    for (int i = 0; i < AbstractHex::getSize()+2; i++)
    {
        board_of_hex[i].resize(AbstractHex::getSize()+2);
    }
    for (int i = 0; i <AbstractHex::getSize()+2; i++)
    {
        board_of_hex[0][i].set_position(upBorder,0,i);
    }
    for (int i = 1; i < AbstractHex::getSize()+2; i++)
    {
        board_of_hex[i][0].set_position(leftBorder,i,0);
        for (int j = 1; j < AbstractHex::getSize()+2; j++)
        {
            board_of_hex[i][j].set_position(empty,i,j);
        }
        board_of_hex[i][AbstractHex::getSize()+1].set_position(rightBorder,i,AbstractHex::getSize()+1);
    }
    for (int i = 0; i <AbstractHex::getSize()+2; i++)
    {
        board_of_hex[AbstractHex::getSize()+1][i].set_position(downBorder,AbstractHex::getSize()+1,i);
    }
}
template <template <typename K,class Alloc = allocator<K>> class T>
void HexAdapter<T>::writeToFile(){
    fstream file;
    string temp;
    cin>>temp;
    file.open(temp,ios::out);
    file<<getSize()<<' ';
    file<<number_of_moves<<' ';
    file<<finished<<' ';
    file<<player_2<<' ';
    for (int i = 0; i < getSize()+2; i++)
    {
        for (int j = 0; j < getSize()+2; j++)
        {
            file<<board_of_hex[i][j].getXoe()<<' ';
        }
    }
    file.close();
}
void  AbstractHex::setSize()
{
    do
    {
        cout<<"Enter the size(size should be bigger than 5)"<<endl;
        cin>>size_of_board;
    } while (size_of_board<=5);
    cout<<"2 Player?(Y/N)"<<endl;
    char temporary;
    cin>>temporary;
    temporary=='Y'?player_2=true:player_2=false;
    this->createBoard();
}
void AbstractHex::Cell::set_position(XorEmptyOrO situation,int letter,int digit)
{
    xeo=situation;
    letter_position=letter;
    digit_position=digit;
}
void AbstractHex::myAtoi()
{
    cout<<"Enter the move:"<<endl;
    char temp[20];
    cin>>temp;
    if(temp[0]=='S'&&temp[1]=='A'&&temp[2]=='V'&&temp[3]=='E')
    {
        writeToFile();
    }
    else if(temp[0]=='L'&&temp[1]=='O'&&temp[2]=='A'&&temp[3]=='D')
    {
        readFromFile();
    }
    else
    {
            if (temp[2]!='\0')
            {
                temporary_x=temp[0]-'A';
                temporary_y=(temp[1]-'0')*10+temp[2]-'1';
                if(player_2==true){
                    if(turn_of_X==true)
                        play(temporary_x,temporary_y,x);
                    else
                        play(temporary_x,temporary_y,o);
                    }
                    else
                        play();
                    
            }
            else if(temp[2]=='\0')
            {
                temporary_x=temp[0]-'A';
                temporary_y=temp[1]-'1';
                if(player_2==true){
                    if(turn_of_X==true)
                        play(temporary_x,temporary_y,x);
                    else
                        play(temporary_x,temporary_y,o);
                    }
                    else
                        play();
            }
        
    }
}
void AbstractHex::setXAndY(int x,int y){
    last_Of_X=x;
    last_Of_Y=y;
}
void HexVector::createBoard(){
    board_of_hex.resize(AbstractHex::getSize()+2);
    for (int i = 0; i < AbstractHex::getSize()+2; i++)
    {
        board_of_hex[i].resize(AbstractHex::getSize()+2);
    }
    for (int i = 0; i <AbstractHex::getSize()+2; i++)
    {
        board_of_hex[0][i].set_position(upBorder,0,i);
    }
    for (int i = 1; i < AbstractHex::getSize()+2; i++)
    {
        board_of_hex[i][0].set_position(leftBorder,i,0);
        for (int j = 1; j < AbstractHex::getSize()+2; j++)
        {
            board_of_hex[i][j].set_position(empty,i,j);
        }
        board_of_hex[i][AbstractHex::getSize()+1].set_position(rightBorder,i,AbstractHex::getSize()+1);
    }
    for (int i = 0; i <AbstractHex::getSize()+2; i++)
    {
        board_of_hex[AbstractHex::getSize()+1][i].set_position(downBorder,AbstractHex::getSize()+1,i);
    }
}
void HexVector::print(){
    for (int i = 0; i < AbstractHex::getSize()+2; i++)
    {
        for (int k = 0; k < i; k++)
        {
            cout<<" ";
        }
        for (int j = 0; j < AbstractHex::getSize()+2; j++)
        {
            if (board_of_hex[i][j].getXoe()==upBorder)
                cout<<"--";
            else if (board_of_hex[i][j].getXoe()==rightBorder)
                cout<<"\\";
            else if (board_of_hex[i][j].getXoe()==leftBorder)
                cout<<"\\";
            else if (board_of_hex[i][j].getXoe()==downBorder)
                cout<<"--";
            else if (board_of_hex[i][j].getXoe()==x)
                cout<<"X ";
            else if (board_of_hex[i][j].getXoe()==o)
                cout<<"O ";
            else
                cout<<"* ";
        }
    cout<<endl;
    }
}
void HexVector::play(int a,int b,XorEmptyOrO xo)
{
    if(board_of_hex[a+1][b+1].getXoe()==empty){
        number_of_moves++;
        board_of_hex[a+1][b+1].set_position(xo,a+1,b+1);
        setXAndY(a+1,b+1);
        this->print();
        if(this->isTurnOfX()==true){
            this->setTurnOfX(false);
                myAtoi();
            }
        else
            setTurnOfX(true);
            //control(a+1,b+1,xo);
        }
    else
    {
        cout<<"The place is filled before. Please enter a new command"<<endl;
        myAtoi();
    }
}
string HexVector::lastMove(){
    if(getLastY()<0)
        throw (myException());
    char temp[3];
    temp[0]=getLastX()+'A'-1;
    if (getLastY()>9)
    {
        temp[1]=(getLastY()/10)+'0';
        temp[2]=(getLastY()%10)+'1'-1;
    }
    else
        temp[1]=getLastY()+'1'-1;    
    return temp;    
}
void HexVector::play(){
    //algorithm is play the user's command if it is true 
    //if it is not true send back to myAtoi function
    //if next cell is empty put the o on it 
    //if it is not empty put the first place at you find 
    bool continue_to_put_computers_move=true;
    if(board_of_hex[temporary_x+1][temporary_y+1].getXoe()==empty)
        board_of_hex[temporary_x+1][temporary_y+1].setXoe(x);
    else{
            cout<<"You entered wrong coordinates"<<endl<<"Please enter again"<<endl;
            myAtoi();
            continue_to_put_computers_move=false;
        }
    if(continue_to_put_computers_move){

        this->print();
        cout<<"Now Computer making the move"<<endl;
        if(board_of_hex[temporary_x+1][temporary_y+2].getXoe()==empty)
            board_of_hex[temporary_x+1][temporary_y+2].setXoe(o);
        else
        {
            int a(0),b(0);
            while (board_of_hex[a][b].getXoe()!=empty)
            {
                a++;
                b++;
            }
               board_of_hex[a][b].setXoe(o);
        }
        this->print();
    }
    cout<<endl;
}
void HexVector::writeToFile(){
    fstream file;
    string temp;
    cin>>temp;
    file.open(temp,ios::out);
    file<<getSize()<<' ';
    file<<number_of_moves<<' ';
    file<<finished<<' ';
    file<<player_2<<' ';
    for (int i = 0; i < getSize()+2; i++)
    {
        for (int j = 0; j < getSize()+2; j++)
        {
            file<<board_of_hex[i][j].getXoe()<<' ';
        }
    }
    file.close();
}
void HexVector::readFromFile(){
    string name_of_file;
    cin>>name_of_file;
    fstream file;
    file.open(name_of_file,ios::in);
    int temp;
    file>>temp;
    setSizeWhileReadingFromFile(temp);
    file>>number_of_moves;
    file>>finished;
    file>>player_2;
    board_of_hex.resize(getSize()+2);
    for (int i = 0; i < getSize()+2; i++)
        board_of_hex[i].resize(getSize()+2);
    for (int i = 0; i < getSize()+2; i++)
    {
        for (int j = 0; j < getSize()+2; j++)
        {
            file>>temp;
            board_of_hex[i][j].setXoe((XorEmptyOrO)temp);
        }
    }
    file.close();
}
void HexVector::reset(){
    for (int i = 0; i < getSize()+2; i++)
        board_of_hex[i].resize(0);
    board_of_hex.resize(0);
    setSizeWhileReadingFromFile(0);
    setTurnOfX(true);
    setLastY(-1);
    finished=false;
    number_of_moves=0;
    setSize();
}
bool HexVector::operator==( AbstractHex& temp){
    if(this->getSize()!=temp.getSize())
        return false;
    for (int i = 0; i < getSize()+2; i++)
    {
        for (int j = 0; j < getSize()+2;j++)
        { 
            try
            {
                if (board_of_hex[i][j].getXoe()!=empty)//if there is extra 1 parameter
                    temp.operator()(i,j);//I can add XorEmptorO and check it much nicer
            }
            catch(const myException& e)
            {
                cerr << e.getSpecifiedException() << endl;
                    return false;
            }
        }
    }
    return true;
}
void HexVector::operator()(int row,int column){
    if (board_of_hex[row][column].getXoe()==empty)
        throw(myException("Empty cell detected,boards are different"));
}
    
void HexArray1D::play(int a,int b,XorEmptyOrO xo){
    if(array_of_1D[a*AbstractHex::getSize()+b].getXoe()==empty){
        number_of_moves++;
    array_of_1D[a*AbstractHex::getSize()+b].set_position(xo,a*AbstractHex::getSize(),b);
    setXAndY(a,b);
        this->print();
        if(this->isTurnOfX()==true){
            this->setTurnOfX(false);
                myAtoi();
            }
        else
            setTurnOfX(true);    
    }
    else
    {
        cout<<"The place is filled before. Please enter a new command"<<endl;
        myAtoi();
    }
}
void HexArray1D::createBoard(){
    array_of_1D=(Cell*)malloc(sizeof(Cell)*AbstractHex::getSize()*AbstractHex::getSize());
    for (int i = 0; i < AbstractHex::getSize()*AbstractHex::getSize(); i++)
    {
        array_of_1D[i].set_position(empty,i/AbstractHex::getSize(),i%AbstractHex::getSize());
    }
}
void HexArray1D::print(){
    
    for (int i =0; i < AbstractHex::getSize()*AbstractHex::getSize(); i++)
    {if (i%AbstractHex::getSize()==0)
        {
            cout<<endl;
            for (int k= 0; k < i; k=k+AbstractHex::getSize())
            {
                cout<<" ";
            }
        }
        if (array_of_1D[i].getXoe()==empty)
            cout<<"* ";
        else if (array_of_1D[i].getXoe()==x)
            cout<<"X ";
        else if (array_of_1D[i].getXoe()==o)
            cout<<"O ";
        
        
    }
    cout<<endl<<endl;
}
string HexArray1D::lastMove(){
    if(getLastY()<0){
        throw (myException("There is no last move"));}
    char temp[3];
    temp[0]=getLastX()+'A';
    if (getLastY()>9)
    {
        temp[1]=(getLastY()/10)+'0';
        temp[2]=(getLastY()%10)+'1';
    }
    else
        temp[1]=getLastY()+'1';
    return temp;        
}
void HexArray1D::play(){
    
    int iterator=temporary_x*getSize()+temporary_y;
    bool continue_to_put_computers_move=true;
    if(array_of_1D[iterator].getXoe()==empty)
        array_of_1D[iterator].setXoe(x);
    else{
            cout<<"You entered wrong coordinates"<<endl<<"Please enter again"<<endl;
            myAtoi();
            continue_to_put_computers_move=false;
        }
    if(continue_to_put_computers_move){

        this->print();
        cout<<"Now Computer making the move"<<endl;
        if(array_of_1D[iterator+1].getXoe()==empty)
            array_of_1D[iterator+1].setXoe(o);
        else
        {
            int a(0);
            while (array_of_1D[a].getXoe()!=empty)
            {
                a++;
            }
               array_of_1D[a].setXoe(o);
        }
        this->print();
    }
    cout<<endl;
}
void HexArray1D::writeToFile(){
    fstream file;
    string filename;
    cin>>filename;
    file.open(filename,ios::out);  
    file<<getSize()<<' ';
    file<<number_of_moves<<' ';
    file<<finished<<' ';
    file<<player_2<<' ';  
    for (int i = 0; i < getSize()*getSize(); i++)
    {
        file<<array_of_1D[i].getXoe()<<' ';
    }
    file.close();
}
void HexArray1D::readFromFile(){
    string name_of_file;
    cin>>name_of_file;
    fstream file;
    file.open(name_of_file,ios::in);
    int temp;
    file>>temp;
    setSizeWhileReadingFromFile(temp);
    file>>number_of_moves;
    file>>finished;
    file>>player_2;
    array_of_1D=(Cell*)malloc(sizeof(Cell)*getSize()*getSize());
    for (int i = 0; i < getSize()*getSize(); i++)
    {
        file>>temp;
        array_of_1D[i].setXoe((XorEmptyOrO)temp);
    }
    file.close();
        
}
void HexArray1D::reset(){
    free(array_of_1D);
    setSizeWhileReadingFromFile(0);//its the same algorithm(take int and put it to size)
    setTurnOfX(true);
    setLastY(-1);
    finished=false;
    number_of_moves=0;
    setSize();
}
bool HexArray1D::operator==(AbstractHex& temp){
    if (this->getSize()!=temp.getSize())
        return false;
    for (int i = 0; i < getSize()*getSize(); i++)
    {
        try
        {
            if (array_of_1D[i].getXoe()!=empty)//if there is extra 1 parameter
                temp.operator()(i);//I can add XorEmptorO and check it much nicer
        }
        catch(const myException& e)
        {
            std::cerr << e.getSpecifiedException() << '\n';
                return false;
        }
    }
    return true;
}
void HexArray1D::operator()(int iterator,int do_not_have_to_use_that){
    if (array_of_1D[iterator].getXoe()==empty)
        throw(myException("Empty cell detected,Boards are not same"));
}
   
AbstractHex::AbstractHex(){
    this->turn_of_X=true;
    this->last_Of_Y=-1;
}

HexArray1D::HexArray1D(){
    this->finished=false;
    this->number_of_moves=0;
}
HexVector::HexVector(){
    this->finished=false;
    this->number_of_moves=0;
}
template <template <class K,class Alloc = allocator<K>> class T>
HexAdapter<T>::HexAdapter(){
    this->finished=false;
    this->number_of_moves=0;
}
void HexVector::control(int a,int b,XorEmptyOrO xoe){
}
template <template <class K,class Alloc = allocator<K>> class T>
void HexAdapter<T>::control(int a,int b,XorEmptyOrO xoe){
}
void HexArray1D::control(int a,int b,XorEmptyOrO xoe){

}
bool global( AbstractHex& temp)
{
    cout<<temp.getSize();
}
HexArray1D::~HexArray1D(){
    free(array_of_1D);
}
