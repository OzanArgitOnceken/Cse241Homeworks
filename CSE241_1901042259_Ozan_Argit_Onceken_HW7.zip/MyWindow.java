
public class MyWindow{
}