public class Hex {
    private int size;
    public int getSize(){return size;}
    public void setSize(int a){size=a;}
    Cell [][]cellArr;

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }
    Hex(int a){
        System.out.println("creating hex");
        size=a;
        cellArr=new Cell[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cellArr[i][j]=new Cell(i,j);
            }
        }
        System.out.println("Hex is created");
    }
}