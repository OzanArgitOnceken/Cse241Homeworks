

public class Main {
    public static void main(String []args){
    //my time was so limited and I tried the best I can do 
    //mycode sometimes creates board but sometimes does not cretes the board 
    //I do not understood why if you figure it out please tell me 
        new MyJFrame();
    }
}
