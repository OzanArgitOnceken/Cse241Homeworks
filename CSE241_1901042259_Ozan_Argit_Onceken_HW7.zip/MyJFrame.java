import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class MyJFrame extends JFrame implements ActionListener{
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private Hex myHex;
    private JButton textButton;
	private JTextField textField;
    private JButton buttonReset;
    private JButton buttonUndo;
    private JButton buttonSave;
    private JButton buttonLoad;
    private JRadioButton vsCPU;
    private JRadioButton vsPlayer;
    private ButtonGroup groupRadio;
    private JPanel panel1 = new JPanel();
    private JPanel panel2 = new JPanel();
    private int IntegerForGrid;

        public MyJFrame(){
            textButton=setButton("Submit");
            textField = new JTextField();
            textField.add(textButton);
            this.setLayout(new BorderLayout());
            panel2.setBackground(Color.lightGray);
            panel1.setPreferredSize(new Dimension(200,100));
            panel2.setPreferredSize(new Dimension(600,600));
            this.add(panel1,BorderLayout.WEST);
            this.add(panel2,BorderLayout.EAST);
            buttonReset=setButton("Reset");
            buttonUndo=setButton("Undo");
            buttonLoad=setButton("Load");
            buttonSave=setButton("Save");
            setRadio();
            panel1.add(textField);
            panel1.setLayout(new GridLayout(IntegerForGrid,0,0,0));
            panel1.add(buttonReset);
            panel1.add(buttonUndo);
            panel1.add(buttonLoad);
            panel1.add(buttonSave);
            panel1.add(vsCPU);
            panel1.add(vsPlayer);
            //panel2.add(myCell.cellButton);
            mySetIcon("Hex.png");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setSize(900, 900);
            this.setResizable(true);
            this.setVisible(true);
        }
    private void mySetIcon(String picName){
        this.setIconImage(new ImageIcon(picName).getImage());
    }
    private void setRadio(){
        vsCPU=new JRadioButton("vs CPU");
        vsPlayer=new JRadioButton("2 Player");
        groupRadio=new ButtonGroup();
        vsCPU.addActionListener(this);
        vsPlayer.addActionListener(this);
        groupRadio.add(vsCPU);
        groupRadio.add(vsPlayer);
        IntegerForGrid++;
        IntegerForGrid++;
    }
    private JButton setButton(String buttonName){
        JButton tempButton;
        tempButton=new JButton();
        tempButton.setBounds(50,50,100,50);//x y width lenght
        tempButton.addActionListener(this);
        tempButton.setText(buttonName);
        tempButton.setFocusable(false);
        IntegerForGrid++;
        return tempButton;

        //buttonReset.setEnable(false)//savede kullanırsın
        
        // buttonReset.addActionListener(e->System.out.println("MyJFrame.setResetButton()"));
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==buttonReset)
        {
            System.out.println("Reset button is working");
        }
        else if(e.getSource()==buttonLoad)
        {
            System.out.println("Load button is working");
        }
        else if(e.getSource()==buttonSave)
        {
            System.out.println("Save button is working");
            JOptionPane.showMessageDialog(null, "Your game saved","Message!", JOptionPane.INFORMATION_MESSAGE);
        }
        else if(e.getSource()==buttonUndo)
        {
            System.out.println("Undo Button is working");
        }
        else if(e.getSource()==textButton)
        {
            System.out.println("You entered"+textField.getText());
            myHex=new Hex(Integer.parseInt(textField.getText()));
            panel2.setLayout(new GridLayout(Integer.parseInt(textField.getText()),Integer.parseInt(textField.getText()),0,0));
            for (int i = 0; i < myHex.getSize(); i++) {
                for (int j = 0; j < myHex.getSize(); j++) {
                    panel2.add(myHex.cellArr[i][j].cellButton);
                }
            }
            System.out.println("Board is created");
        }
    }
    
    
}
