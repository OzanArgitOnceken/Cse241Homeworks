import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Cell implements ActionListener {
    public int row;
    public int column;
    public JButton cellButton;
    Cell(int i,int j)
    {
        row=i;
        column=j;

        cellButton=new JButton();
        cellButton.setBounds(50,80,5,5);//x y width lenght
        cellButton.addActionListener(this);
        cellButton.setFocusable(false);
    }    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==cellButton)
        {
            System.out.println("you pressed:"+(row+1)+(column+1));
        }
        
    }
}
