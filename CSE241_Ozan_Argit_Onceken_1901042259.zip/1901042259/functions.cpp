#include "myLib.h"
#include <iostream>
using namespace std;
void makeBoard(int board[14][sizeOfArray],int size)
{
/*
        purpose of this function is making the up and down side 2 and -2 
        left and right is 0 and 9 for control
        if there is 1 it means there is empty you can put X or O
        my board looks like 1010101..-> it is for aesthetics 
*/
    int j,i,k;
    for (int i = 0; i < sizeOfArray; i++)
    {
        board[0][i]=2;
    }
    
    for (i = 1; i <= size; i++)
    {
            for (k= 0; k < i; k++)
            {
                board[i][k]=0;
            }
            for (j = 0; j < size*2; j++)
            {
                board[i][k+j]=1;
                j++;
                board[i][k+j]=0;
            }for ( ; j <=sizeOfArray; j++)
            {
                board[i][k+j]=9;
            }
            
    }
    for (int j= 0; j < sizeOfArray; j++)
    {
        board[i][j]=-2;
    }
    
}
void printBoardintForTest(int board[14][sizeOfArray],int size)
{//control for ints
    for (int i = 0; i <= size+1; i++)
    {
        for (int j = 0; j <=sizeOfArray; j++)
        {
            cout<<board[i][j];
        }
        cout<<endl;
    }
    
}
void printBoard(int board[14][sizeOfArray],int count)
{//I am printing the board  
    cout<<"   ";
    char letters[]={"abcdefghijklm"};
    for (int i = 0; i < count; i++)
    {
        cout<<letters[i]<<"   ";
    }
    cout<<endl;
    for (int i = 1; i <=count; i++)
    {
        i!=0?cout<<i:cout<<"";
        for (int j = 0; j < sizeOfArray; j++)
        {
           if(board[i][j]==1)
                cout<<"* ";//spaces for aesthetics again
           else if(board[i][j]==4)
                cout<<"X ";
           else if(board[i][j]==6)
                cout<<"O ";
           else
               cout<<"  ";  
        }
        cout<<endl;
    }
    
}
int takeInput(int board[14][sizeOfArray],int size,char pCho)
{//this function makes moves if it is ok to move and decide 2 player or 1  
    int test1=0,test2=0;
    cout<<"Plajer1's move:";
    int i,j;
    myAtoi(&i,&j);
    while (board[j][i*2+j]!=1)//if the stated coordinate does not exist or fulled take new input while it is not ok
    {
        cout<<"Plajer1 entered wrong coordinations please enter new coordinate."<<endl;
        myAtoi(&i,&j);

    }
    board[j][i*2+j]=4;//make the stated coordinate 4 for X
    printBoard(board,size);
    control(board,j,(i*2+j),&test1,&test2,-999,-999,0,9,4,9999,99999);
    if(test1+test2==2){//if 2 sides are reached
        cout<<"!!! PLAYER X WON THE GAME !!!"<<endl;
        return 0;
        }
        test2=0;
        test1=0;
        if (pCho=='Y')
        {
            cout<<"Plajer2's move:"<<endl;//same think with player one's
            myAtoi(&i,&j);
            while (board[j][2*i+j]!=1)
            {
                cout<<"Plajer2 entered wrong coordinations please enter new coordinate."<<endl;
                myAtoi(&i,&j);
            }
            test1=0,test2=0;
            board[j][2*i+j]=6;
            printBoard(board,size);
            control(board,j,(i*2+j),&test1,&test2,-999,-999,2,-2,6,1111,1111);
            if(test1+test2==2)
            {
                cout<<"!!!PLAYER2 (O) WON THE GAME !!!"<<endl;
                return 0;
            }
        }
        else
        {
                /*
                    in here I tried a strategy:
                    at first put the O right of X so X can not reach the right side
                    if right of it is fulled put O in left
                    else the other ways
                    if all ways are blocked put it at first empty coordinate you saw 
                */
                cout<<"Computer's move:"<<endl;
                int sendi,sendj;
                if(board[j][2*i+j+2]==1)
                {
                    board[j][2*i+j+2]=6;
                    sendj=j;
                    sendi=2*i+j+2;
                }
                else if(board[j][2*i+j-2]==1){
                    board[j][2*i+j-2]=6;
                    sendi=2*i+j-2;
                    sendj=j;
                    }
                else if(board[j-1][2*i+j-1]==1){
                    board[j-1][2*i+j-1]=6;
                    sendj=j-1;
                    sendi=2*i+j-1;}
                else if(board[j+1][2*i+j-1]==1){
                    board[j+1][2*i+j-1]=6;
                    sendj=j+1;
                    sendi=2*i+j-1;}
                else if(board[j+1][2*i+j+1]==1){
                    board[j+1][2*i+j+1]=6;
                    sendi=2*i+j+1;
                    sendj=j+1;}
                else if(board[j-1][2*i+j+1]==1){
                    board[j-1][2*i+j+1]=6;
                    sendj=j-1;
                    sendi=2*i+j+1;}
                else{
                    int test=0;
                        for (int a = 0; a < 14&&test==0; a++)
                        {
                            for (int b = 0; b < sizeOfArray&&test==0; b++)
                            {
                                if (board[a][b]==1)
                                {
                                    board[a][b]=6;
                                    test++;
                                }
                                    
                            }
                            
                        }
                    }
            printBoard(board,size);
            control(board,sendj,sendi,&test1,&test2,-999,-999,2,-2,6,1111,1111);
            if(test1+test2==2)
            {
                cout<<"!!!COMPUTER (O) WON THE GAME !!!"<<endl;
                return 0;
            }

        }
    return 1;

}
void myAtoi(int *i,int *j)
{//it takes first character as char and second as integer
    char a;
    int p;
    cin>>a>>p;
    *i=a-'A';
    *j=p;
}
int control(int board[14][sizeOfArray],int i,int j,int *t1,int *t2,int previ,int prevj,int border1,int border2,int num,int previ2,int prevj2)
{//controll with recursive because recursive makes continuıos
    if(board[i][j]==num)//num is X or O (which called from ınput function) 
    {
        if (j-2!=prevj&&j-2!=prevj)//if it controlls the previous one it makes infinity loop
            control(board, i,j-2, t1,t2,i,j,border1,border2,num,previ,prevj);//here I am sending new coordinates ,testing integers borders and num
        if (j+2!=prevj&&j+2!=prevj)  
        control(board, i,j+2, t1,t2,i,j,border1,border2,num,previ,prevj);//(borders are sended from ınput function)
        if ((j-1!=prevj&&previ!=i-1)&&(j-1!=prevj&&previ!=i-1))  
            control(board, i-1,j-1, t1,t2,i,j,border1,border2,num,previ,prevj);
        if ((i+1!=previ&&j+1!=prevj)&&(i+1!=previ2&&j+1!=prevj2))        
            control(board, i+1,j+1, t1,t2,i,j,border1,border2,num,previ,prevj);
        if((i-1!=previ&&j+1!=prevj)&&(i-1!=previ2&&j+1!=prevj2))
            control(board, i-1,j+1, t1,t2,i,j,border1,border2,num,previ,prevj);
        if((i+1!=previ&&j-1!=prevj)&&(i+1!=previ2&&j-1!=prevj2))
            control(board, i+1,j-1, t1,t2,i,j,border1,border2,num,previ,prevj);
    }
    else if (board[i][j]==border1)//if the reached point is at border make test integer=1
        *t1=1;
    else if(board[i][j]==border2)
        *t2=1;
        /*
            I added previ and prevj because if (X for example) X has 2 X near of it goes x1->x2->x3->x1->x2...
            previ and prevj remembers the x1 when it is on x3 so it prevents the infinity loop
        */
}