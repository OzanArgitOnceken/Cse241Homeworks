//here is the headers...
#ifndef myLib
#define myLib

#define sizeOfArray 60
void makeBoard(int board[14][sizeOfArray],int);
void printBoardintForTest(int board[14][sizeOfArray],int);
void printBoard(int [14][sizeOfArray],int);
int takeInput(int [14][sizeOfArray],int,char);
int okToPut(int [14][sizeOfArray],int,int);
void myAtoi(int *i,int *j);
int control(int board[14][sizeOfArray],int i,int j,int *t1,int *t2,int,int,int,int,int,int ,int);
#endif 
