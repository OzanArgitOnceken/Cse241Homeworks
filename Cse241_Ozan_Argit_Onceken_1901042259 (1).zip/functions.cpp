#include "myLib.h"
void makeBoard(int board[14][sizeOfArray],int size)
{
/*
        purpose of this function is making the up and down side 2 and 3
        left and right is 0 and 9 for control
        if there is 1 it means there is empty you can put X or O
        my board looks like 1010101..-> it is for aesthetics 
*/
    int j,i,k;
    for (int i = 0; i <= sizeOfArray; i++)
    {
        board[0][i]=upBorder;
    }
    
    for (i = 1; i <= size; i++)
    {
            for (k= 0; k < i; k++)
            {
                board[i][k]=leftBorder;
            }
            for (j = 0; j < size*2; j++)
            {
                board[i][k+j]=okToPut;
                j++;
                board[i][k+j]=leftBorder;
            }for ( ; j <=sizeOfArray; j++)
            {
                board[i][k+j]=rightBorder;
            }
            
    }//I change -2 to 3 because my load file will read char and - and 2 is diffirent so 3 is easier to read
   
    for ( ; i < 14; i++)
    {cout<<i<<endl;
        for (j = 0; j < sizeOfArray; j++)
        {
            board[i][j]=downBorder;
        }
        
    }
    
    
}
void printBoardintForTest(int board[14][sizeOfArray])
{//control for ints at debugging
    for (int i = 0; i <= 13; i++)
    {
        for (int j = 0; j <=sizeOfArray; j++)
        {
            cout<<board[i][j];
        }
        cout<<endl;
    }
    
}
void printBoard(int board[14][sizeOfArray])
{//I am printing the board  
    cout<<"  ";
    char letters[]={"abcdefghijkl"};
    for (int i = 0; i <12; i++)
    {
        cout<<letters[i]<<"   ";
    }
    cout<<endl;
    for (int i = 1; i <=12; i++)
    {
        i!=0?cout<<i:cout<<"";
        for (int j = 0; j < sizeOfArray; j++)
        {
           if(board[i][j]==okToPut)
                cout<<"* ";//spaces for aesthetics again
           else if(board[i][j]==X)
                cout<<"X ";
           else if(board[i][j]==O)
                cout<<"O ";
           else
               cout<<"  ";  
        }
        cout<<endl;
    }
    
}
int takeInput(int board[14][sizeOfArray],char *pCho,bool xTurn)
{//this function makes moves if it is ok to move and decide 2 player or 1  
    int test1=0,test2=0;
    int i,j;
    if(xTurn)
    {cout<<"Plajer1's move:";
    *pCho=myAtoi(&i,&j,board,*pCho);//I should change players choice for if customer wants to load a file
    while (board[j][i*2+j]!=okToPut)//if the stated coordinate does not exist or fulled take new input while it is not ok
    {
        cout<<"Plajer1 entered wrong coordinations please enter new coordinate."<<endl;
        *pCho=myAtoi(&i,&j,board,*pCho);
    }
    board[j][i*2+j]=X;//make the stated coordinate 4 for X
    printBoard(board);
    control(board,j,(i*2+j),&test1,&test2,-999,-999,leftBorder,rightBorder,X,9999,99999);
    if(test1+test2==2){//if 2 sides are reached
        cout<<"!!! PLAYER X WON THE GAME !!!"<<endl;
        return 0;
        }
    }
    test2=0;
    test1=0;
    if (*pCho=='Y'){
        cout<<"Plajer2's move:"<<endl;//same think with player one's
        *pCho=myAtoi(&i,&j,board,*pCho);
        while (board[j][2*i+j]!=okToPut){
            cout<<"Plajer2 entered wrong coordinations please enter new coordinate."<<endl;
            *pCho=myAtoi(&i,&j,board,*pCho);
        }
        test1=0,test2=0;
        board[j][2*i+j]=O;
        printBoard(board);
        control(board,j,(i*2+j),&test1,&test2,-999,-999,downBorder,upBorder,O,1111,1111);
        if(test1+test2==2){
            cout<<"!!!PLAYER2 (O) WON THE GAME !!!"<<endl;
            return 0;
        }
    }
            /*
                in here I tried a strategy:
                at first put the O right of X so X can not reach the right side
                if right of it is fulled put O in left
                else the other ways
                if all ways are blocked put it at first empty coordinate you saw 
            */else
            {
            cout<<"Computer's move:"<<endl;
            int sendi,sendj;
            if(board[j][2*i+j+2]==okToPut)
            {
                board[j][2*i+j+2]=O;
                sendj=j;
                sendi=2*i+j+2;
            }
            else if(board[j][2*i+j-2]==okToPut){
                board[j][2*i+j-2]=O;
                sendi=2*i+j-2;
                sendj=j;
                }
            else if(board[j-1][2*i+j-1]==okToPut){
                board[j-1][2*i+j-1]=O;
                sendj=j-1;
                sendi=2*i+j-1;}
            else if(board[j+1][2*i+j-1]==okToPut){
                board[j+1][2*i+j-1]=O;
                sendj=j+1;
                sendi=2*i+j-1;}
            else if(board[j+1][2*i+j+1]==okToPut){
                board[j+1][2*i+j+1]=O;
                sendi=2*i+j+1;
                sendj=j+1;}
            else if(board[j-1][2*i+j+1]==okToPut){
                board[j-1][2*i+j+1]=O;
                sendj=j-1;
                sendi=2*i+j+1;}
            else{
                int test=0;
                    for (int a = 0; a < 14&&test==0; a++)
                    {
                        for (int b = 0; b < sizeOfArray&&test==0; b++)
                        {
                            if (board[a][b]==okToPut)
                            {
                                board[a][b]=O;
                                test++;
                            }
                                
                        }
                        
                    }
                }
        printBoard(board);
        control(board,sendj,sendi,&test1,&test2,-999,-999,downBorder,upBorder,O,1111,1111);//I'm using enums here
        if(test1+test2==2)
        {
            cout<<"!!!COMPUTER (O) WON THE GAME !!!"<<endl;
            return 0;
        }
    }
    return 1;
}
char myAtoi(int *i,int *j,int board[14][sizeOfArray],char pCho)
{
    /*
        In hw1 this function only takes moves but new function
        checks if it says LOAD or SAVE .
        It saves the current game
    */
  
    char loadChoice;
  string move;
  cin>>move;
  cout<<move<<endl;
  if(move[0]=='L'&&move[1]=='O'&&move[2]=='A'&&move[3]=='D')
    {
        char loadName[50];
        cin>>loadName;
        loadChoice=loadFile(loadName,board);//read this function for instruction
        cin.clear();
        for (int a = 0; a <14; a++)
        {
            for (int b = 0; b < sizeOfArray; b++)
            {
                if(board[a][b]==okToPut){
                *j=a;
                *i=2*b+a;}
            }
            
        }
        
        return loadChoice;  
    }
    else if(move[0]=='S'&&move[1]=='A'&&move[2]=='V'&&move[3]=='E')
    {
        char saveName[50];
        cin>>saveName;
        saveFile(saveName,board,pCho);//read this function for instruction
    }
    else//if it is not save or load do next move
    {
        *i=move[0]-'A';
        if(move[2]!='\0')
        {
            *j=(move[1]-'0')*10+move[2]-'0';
        }
        else
            *j=move[1]-'0';
        cout<<"Player make move to "<<move[0]<<move[1]<<endl;
    }
    return pCho;
}
void saveFile(const char* saveName,int board[14][sizeOfArray],char pcho){
    //this function writes all board to file
    cerr<<"Saving the file: "<<saveName<<endl;
    ofstream savingFile;
    ofstream allFiles;
    allFiles.open("All File Names",ios::app);//this holds all names of the files and I will use it while loading screen
    allFiles<<saveName<<endl;
    allFiles.close();
    savingFile.open(saveName);
    for (int i = 0; i < 14; i++)
    {
        for (int j= 0; j < sizeOfArray; j++)
        {
            char a;
            savingFile<<board[i][j];
        }
        savingFile<<endl;
    }
    savingFile<<pcho;
    savingFile.close();
    cerr<<"Saving succesfully done."<<endl;
    printBoard(board);

}
char loadFile(char* loadName,int board[14][sizeOfArray]){
    //this function reads the file and fill array but if load file does not exists . . .
    ifstream loadedFile;
    loadedFile.open(loadName);
    int which=0;
    while (!loadedFile.is_open())
    {
        cerr<<"There is no file named: "<<loadName<<endl<<"Files that you have:"<<endl;
        myUtilityFunction(loadName,"All File Names");
        loadedFile.open(loadName);
    }
    for (int i = 0; i < 14; i++)
    {
        for (int j = 0; j <sizeOfArray; j++)
        {
            char readed;
            loadedFile>>readed;
            board[i][j]=readed-'0';
            if(readed-'0'==X)
                which++;
            else if(readed-'0'==O)
                which--;
        }
    }
    char a;
    loadedFile>>a;
    loadedFile.close();
    printBoard(board);
    if(which>0)
        takeInput(board,&a,false);
    else
        takeInput(board,&a,true);
        return a;
}

template<typename variable,typename variable2>
void myUtilityFunction(variable name,variable2 allFilesTxt)
{
    /*
        this is a declrtype function (I do not want to rewrite my old functions instead of that I
        wrote this function.)
        it reads the All existed file names and asks user to chose one of them
    */
    ifstream readingFile;
    readingFile.open(allFilesTxt);
    string a;
    while(readingFile>>a)
    {
        cout<<a<<endl;
    }
    cout<<"Enter new load file: ";
    cin>>name;

}
int control(int board[14][sizeOfArray],int i,int j,int *t1,int *t2,int previ,int prevj,int border1,int border2,int num,int previ2,int prevj2)
{//controll with recursive because recursive makes continuıos
    if(board[i][j]==num)//num is X or O (which called from ınput function) 
    {
        if (j-2!=prevj&&j-2!=prevj)//if it controlls the previous one it makes infinity loop
            control(board, i,j-2, t1,t2,i,j,border1,border2,num,previ,prevj);//here I am sending new coordinates ,testing integers borders and num
        if (j+2!=prevj&&j+2!=prevj)  
        control(board, i,j+2, t1,t2,i,j,border1,border2,num,previ,prevj);//(borders are sended from ınput function)
        if ((j-1!=prevj&&previ!=i-1)&&(j-1!=prevj&&previ!=i-1))  
            control(board, i-1,j-1, t1,t2,i,j,border1,border2,num,previ,prevj);
        if ((i+1!=previ&&j+1!=prevj)&&(i+1!=previ2&&j+1!=prevj2))        
            control(board, i+1,j+1, t1,t2,i,j,border1,border2,num,previ,prevj);
        if((i-1!=previ&&j+1!=prevj)&&(i-1!=previ2&&j+1!=prevj2))
            control(board, i-1,j+1, t1,t2,i,j,border1,border2,num,previ,prevj);
        if((i+1!=previ&&j-1!=prevj)&&(i+1!=previ2&&j-1!=prevj2))
            control(board, i+1,j-1, t1,t2,i,j,border1,border2,num,previ,prevj);
    }
    else if (board[i][j]==border1)//if the reached point is at border make test integer=1
        *t1=1;
    else if(board[i][j]==border2)
        *t2=1;
        /*
            I added previ and prevj because if (X for example) X has 2 X near of it goes x1->x2->x3->x1->x2...
            previ and prevj remembers the x1 when it is on x3 so it prevents the infinity loop
        */
}