#include "myLib.h"

int main(){
    char welcome[]="\n!!!Welcome the Hex Game!!!\nWE HAVE NEW UTİLİTİES LİKE ALL SAVED FİLE NAMES AND SAVE AND LOAD FUNCTİON\n Rules: Player X should make connected between right and left\nPlayer O should make connected up and down sides\n(Hint:Read the ReadMe file If you think you win but there is no celebration)\nYour Inputs should look like :A1\nB2\nG4\n";
    int iter=0;
    while (welcome[iter]!='\0')
    {
        welcome[iter]=='\n'?cout<<"\n*": cout<<welcome[iter];
        iter++;
    }
    int board[14][sizeOfArray];//this is the board of int for control easily
    int size;
    do{
        cout<<"Enter the size:";
        cin>>size;
    }while (!(size<=12&&size>=6));
    
    cout<<"2 player(Enter Y for yes N for no)";//if yes
    char p2;
    cin>>p2;
    cout<<p2<<endl;
    makeBoard(board,size);//in here I am making the board
    #ifdef DEBUG //I realised that in here I can write anything instead of DEBUG but DEBUG is much easy to understand if it does not works like I sad please tell me (I want to learn)
    printBoardintForTest(board);
    #endif
    printBoard(board);//And printing in here
    while (takeInput(board,&p2));
}