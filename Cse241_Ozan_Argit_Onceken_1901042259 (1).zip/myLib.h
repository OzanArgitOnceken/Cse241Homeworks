
#include <iostream>
#include<fstream>
using namespace std;
#ifndef myLib
//here is the headers...
#define myLib
enum player{
    okToPut,X,O,leftBorder,rightBorder,upBorder,downBorder
};
#define sizeOfArray 60
void makeBoard(int board[14][sizeOfArray],int);
void printBoardintForTest(int board[14][sizeOfArray]);
void printBoard(int [14][sizeOfArray]);
int takeInput(int [14][sizeOfArray],char*,bool=true);
char myAtoi(int *i,int *j,int board[14][sizeOfArray],char);
int control(int board[14][sizeOfArray],int i,int j,int *t1,int *t2,int,int,int,int,int,int ,int);
void saveFile(const char* ,int [14][sizeOfArray],char);
char loadFile(char* ,int [14][sizeOfArray]);
template<typename variable,typename variable2>
void myUtilityFunction(variable,variable2);
#endif 
